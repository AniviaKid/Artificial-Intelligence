# -*- coding: UTF-8 -*-
import math
import numpy as np
import csv
import random
traindata=[]
trainlabel=[]
testdata=[]
filename='trainprocess.csv'
out=open('5_v1.csv','w') #type 0 10 100 1000

with open(filename)as trainfile:
	lines=csv.reader(trainfile)
	for line in lines:
		trainlabel.append(int(line[len(line)-1]))
		one = line[0:len(line)-1]
		traindata.append(one)
	traindata=np.array(traindata,np.double)

with open(r'testprocess.csv') as valfile:
	lines=csv.reader(valfile)
	for line in lines:
		one=line[0:len(line)]
		testdata.append(one)
	testdata=np.array(testdata,np.double)

k=1
flag=0
for i in range(0,len(testdata)):
	tmp=traindata-testdata[i]
	#tmp=tmp**2
	tmp=np.abs(tmp)
	tmp=np.sum(tmp,axis=1)
	
	sortindex=np.argsort(tmp)
	one=0
	zero=0

	for j in range(k):
		if trainlabel[sortindex[j]]==1:
			one=one+1
		elif trainlabel[sortindex[j]]==0:
			zero=zero+1
	if one>zero:
		predict=1
	else:
		predict=0

	if flag==0:
		flag=1
		out.write(str(predict))
	else :
		out.write('\n'+str(predict))
