# -*- coding: UTF-8 -*-
import math
import numpy as np
import csv
import random

out1=open('trainprocess.csv','w')
cnt=0
flag=0
with open(r'train.csv') as trainfile:
	lines=csv.reader(trainfile)
	for line in lines:
		if flag!=0:
			out1.write('\n')
		else :
			flag=1
		tmp=[0,0,0,0]
		out1.write(str(line[0]))
		one=line[0:1]
		if line[1]=='type_A':
			tmp=tmp
		elif line[1]=='type_B':
			tmp[0]=1
		elif line[1]=='type_C':
			tmp[1]=1
		elif line[1]=='type_D':
			tmp[2]=1
		elif line[1]=='type_E':
			tmp[3]=1
		#out1.write(str(tmp[0]))
		for i in range(4):
			out1.write(','+str(tmp[i]))
		for i in range(2,len(line)):
			out1.write(','+str(line[i]))
'''


out2=open('testprocess.csv','w')
cnt=0
flag=0
with open(r'test.csv') as trainfile:
	lines=csv.reader(trainfile)
	for line in lines:
		if flag!=0:
			out2.write('\n')
		else :
			flag=1
		tmp=[0,0,0,0]
		out2.write(str(line[0]))
		one=line[0:1]
		if line[1]=='type_A':
			tmp=tmp
		elif line[1]=='type_B':
			tmp[0]=1
		elif line[1]=='type_C':
			tmp[1]=1
		elif line[1]=='type_D':
			tmp[2]=1
		elif line[1]=='type_E':
			tmp[3]=1
		#out1.write(str(tmp[0]))
		for i in range(4):
			out2.write(','+str(tmp[i]))
		for i in range(2,len(line)):
			out2.write(','+str(line[i]))
'''