knn.py 是跑出最好结果的代码文件

dataprocess.py 是将数据集进行独热编码的文件

testprocess.csv, trainprocess.csv 是将测试集和训练集进行独热编码后的文件 
