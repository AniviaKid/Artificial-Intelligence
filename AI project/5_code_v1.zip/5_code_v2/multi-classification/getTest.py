import csv


ans =[]

with open('test_label.txt','r') as text:
    lines = text.readlines()
    for line in lines:
        if line.replace('\n','')=="1":
            ans.append(['LOW'])
        elif line.replace('\n','')=="2":
            ans.append(['MID'])
        else:
            ans.append(['HIG'])


with open('ans.csv','w') as text:
    f1 = csv.writer(text)
    for line in ans:
        f1.writerow(line)






