epochs = 5000;
lr = 0.15;

for i=1:epochs % iterations
    %caculate gradient
     grads=tr_input'*(f(tr_input*w)-tr_label);
       
     w = w-lr/tr_num*grads;
     
     tr_output = f(tr_input*w);
     val_output = f(val_input*w);
     [max_,index1]=max(tr_output,[],2);
     [max_,index2]=max(val_output,[],2);
     acc_tr =[acc_tr mean(index1==tr_index)];
     acc_val =[acc_val mean(index2==val_index)];
     
     if (mod(i,50)==0)
         i/epochs
     end
     
     if(max(acc_val)==mean(index2==val_index))
         WMAX=w;
     end
end

plot(acc_tr);
hold on;
plot(acc_val);
legend('trainset','validationset');
title('acc');
xlabel('iterations');
