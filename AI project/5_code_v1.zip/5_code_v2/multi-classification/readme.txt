数据集处理使用的python,模型的训练以及预测使用的是matlab
运行顺序:
1. python doc2vec.py
2. matlab LR
3. matlab LR_getAns
4. python getTest

最后生成的ans.csv即为预测得到的测试集标签
如果第二步中发现还没有收敛，可以再跑一次LR continue