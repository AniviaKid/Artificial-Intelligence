
clear all;
%train = csvread('word2vec_trainvec2.csv');%read data
%test = csvread('word2vec_testvec2.csv');
load train.txt
load test.txt

[train_num dim] = size(train);%get number of row or col 
[te_num dim] = size(test);



for i=1:dim
    max_=max(train(:,i));
    min_=min(train(:,i));
    train(:,i) = (2*train(:,i)-(min_+max_)*ones(train_num,1))/(max_-min_);
    test(:,i) = (2*test(:,i)-(min_+max_)*ones(te_num,1))/(max_-min_);
end

%�[�W���m
train_input = [ones(train_num,1) train(:,1:dim)];
train_label = csvread('trainlabel.csv');%?��??

dim = dim+1;

[max_label,train_index]=max(train_label,[],2);

%divide trainset and validationset

indices = crossvalind('Kfold', train_num, 5);
val = (indices == 5);
val_input = train_input(val,:);
val_label = train_label(val,:);
val_index = train_index(val,:);
tr = ~val;
tr_input = train_input(tr,:);
tr_label = train_label(tr,:);
tr_index = train_index(tr,:);

[tr_num dim] =  size(tr_input);
[val_num dim] = size(val_input);


w = rand(dim,3);%�����?���V�q
%detw = zeros(dim,3);%���

epochs = 5000;
lr = 0.3;
f=@(x)sigmf(x,[1 0]); %activation function
detf=@(x)(sigmf(x,[1 0]).*(1-sigmf(x,[1 0])));

acc_tr=[];
acc_val=[];

for i=1:epochs % iterations
    %caculate gradient
     grads=tr_input'*(f(tr_input*w)-tr_label);
       
     w = w-lr/tr_num*grads;
     
     tr_output = f(tr_input*w);
     val_output = f(val_input*w);
     [max_,index1]=max(tr_output,[],2);
     [max_,index2]=max(val_output,[],2);
     acc_tr =[acc_tr mean(index1==tr_index)];
     acc_val =[acc_val mean(index2==val_index)];
     if (mod(i,20)==0)
         i/epochs
     end
end


plot(acc_tr);
hold on;
plot(acc_val);
legend('trainset','validationset');
title('acc');
xlabel('iterations');
