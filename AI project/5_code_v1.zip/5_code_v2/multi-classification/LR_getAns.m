test_input = [ones(te_num,1) test];
test_output = f(test_input*WMAX);
[max_,index3]=max(test_output,[],2);

csvwrite('test_label.txt',index3);