import gensim
import numpy as np
import csv
from gensim.models.doc2vec import LabeledSentence

def labelize(texts,label_type):
    labelized = []
    for i,v in enumerate(texts):
        label = '{}_{}'.format(label_type,i)
        labelized.append(LabeledSentence(v, [label]))
    return labelized


train_text=[]
test_text=[]

fr=open('MulLabelTrain.ss')
for line in fr:
    train_text.append(line.split('\t\t')[1].replace("<sssss> ","").split(" "))

fr=open('MulLabelTest.ss')
for line in fr:
    test_text.append(line.split('\t\t')[1].replace("<sssss> ","").split(" "))



all_text = train_text+test_text


all_text_labelized=labelize(all_text,"test")

model=gensim.models.Doc2Vec(all_text_labelized,size=3000,window=3)#5_genism_models_Doc2Vec

model.train(all_text_labelized,total_examples=model.corpus_count, epochs=model.iter)#5_genism_models_train

train_vec = model.docvecs[np.arange(len(train_text))]#5_genism_models_docves
test_vec = model.docvecs[np.arange(len(train_text),len(train_text)+len(test_text))]#5_genism_models_docves

np.savetxt("train.txt", train_vec)
np.savetxt("test.txt", test_vec)

trainlabel = open('trainlabel.csv','w')
writer2 = csv.writer(trainlabel)
with open('./multi-classification/MulLabelTrain.ss', 'r') as trainfile:
    lines = trainfile.readlines()
    for line in lines:
        if line.split('\t\t')[0] == 'LOW':
            writer2.writerow([1,0,0])
        elif line.split('\t\t')[0] == 'MID':
            writer2.writerow([0,1,0])
        else:
            writer2.writerow([0,0,1])


